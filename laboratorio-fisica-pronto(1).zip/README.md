# Laboratório de Física

Site estático com simulações interativas de Física.

## Estrutura

- `index.html` — estrutura da página
- `css/style.css` — estilos
- `js/main.js` — lógica e simulações

## Publicar gratuitamente no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde o GitHub Pages publicar o site.

O arquivo inicial precisa continuar se chamando `index.html`.
